const TelegramBot = require('node-telegram-bot-api');
const { exec } = require('child_process');

const TOKEN = '7953102586:AAFzb2yemJZe5W7915gP5meTM1lLEVXdz9A';
const ADMIN = ['7545471466']; // ID Telegram admin
const bot = new TelegramBot(TOKEN, { polling: true });

function isAdmin(id){ return ADMIN.includes(id.toString()); }

const mainMenu = {
  reply_markup:{
    inline_keyboard:[
      [{text:'➕ Tambah User',callback_data:'create_user'}],
      [{text:'⚡ Tambah Trial',callback_data:'create_trial'}],
      [{text:'📋 List User',callback_data:'list_user'}],
      [{text:'🗑 Hapus Expired',callback_data:'delete_expired'}],
      [{text:'🌐 Lihat Host',callback_data:'view_host'}],
      [{text:'✏ Set Host',callback_data:'set_host'}],
      [{text:'🔄 Reset Host',callback_data:'reset_host'}],
      [{text:'💾 Backup',callback_data:'backup'}],
      [{text:'♻ Restore',callback_data:'restore'}]
    ]
  }
};

bot.onText(/\/start/,m=>{
  if(!isAdmin(m.from.id)) return bot.sendMessage(m.chat.id,'❌ Bukan admin');
  bot.sendMessage(m.chat.id,'🌐 UDP Bot Telegram',mainMenu);
});

bot.on('callback_query',query=>{
  const chatId=query.message.chat.id;
  if(!isAdmin(query.from.id)) return bot.sendMessage(chatId,'❌ Bukan admin');

  switch(query.data){
    case 'create_user':
      bot.sendMessage(chatId,'Format: username password expire maxlogin')
        .then(()=>bot.once('message',msg=>{
          const a=msg.text.split(' ');
          if(a.length<4) return bot.sendMessage(chatId,'❌ Format salah');
          exec(`bash /root/udp/udp_bot.sh create_user ${a.join(' ')}`,(err,out)=>bot.sendMessage(chatId,err?err.message:out));
        }));
      break;
    case 'create_trial':
      exec('bash /root/udp/udp_bot.sh create_trial',(e,o)=>bot.sendMessage(chatId,o));
      break;
    case 'list_user':
      exec('bash /root/udp/udp_bot.sh list_user',(e,o)=>bot.sendMessage(chatId,o));
      break;
    case 'delete_expired':
      exec('bash /root/udp/udp_bot.sh delete_expired_manual',(e,o)=>bot.sendMessage(chatId,o));
      break;
    case 'view_host':
      exec('bash /root/udp/udp_bot.sh view_host',(e,o)=>bot.sendMessage(chatId,o));
      break;
    case 'set_host':
      bot.sendMessage(chatId,'Masukkan host baru:')
        .then(()=>bot.once('message',msg=>{
          exec(`bash /root/udp/udp_bot.sh set_host ${msg.text}`,(e,o)=>bot.sendMessage(chatId,o));
        }));
      break;
    case 'reset_host':
      exec('bash /root/udp/udp_bot.sh reset_host',(e,o)=>bot.sendMessage(chatId,o));
      break;
    case 'backup':
      exec('bash /root/udp/udp_bot.sh backup_data',(e,o)=>bot.sendMessage(chatId,o));
      break;
    case 'restore':
      bot.sendMessage(chatId,'Masukkan link backup:')
        .then(()=>bot.once('message',msg=>{
          exec(`bash /root/udp/udp_bot.sh restore_data <<< "${msg.text}"`,(e,o)=>bot.sendMessage(chatId,o));
        }));
      break;
  }
});