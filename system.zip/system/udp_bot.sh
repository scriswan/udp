#!/bin/bash
# UDP user manager lengkap & perbaikan parsing tanggal

# ===== WARNA & FORMAT =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[93m"
CYAN="\e[36m"
BOLD="\e[1m"
RESET="\e[0m"

# ===== PATH =====
HOST_FILE="/root/udp/host.conf"
EXP_FILE="/etc/expuser.conf"
BACKUP_DIR="/root/udp/backup"

mkdir -p /root/udp "$BACKUP_DIR"
[[ ! -f $EXP_FILE ]] && touch $EXP_FILE

# ===== FUNGSI HOST =====
get_host(){ [[ -s $HOST_FILE ]] && cat "$HOST_FILE" || curl -s https://ipecho.net/plain || echo "127.0.0.1"; }
view_host(){ echo -e "${CYAN}🌐 Host Aktif : $(get_host)${RESET}"; }
set_host(){ echo "$1" > "$HOST_FILE"; echo -e "${GREEN}✅ Host diubah: $1${RESET}"; }
reset_host(){ rm -f "$HOST_FILE"; echo -e "${GREEN}✅ Host direset ke IP VPS${RESET}"; }

# ===== FUNGSI USER =====
create_user(){
    local u="$1" p="$2" e="$3" m="$4"
    [[ -z "$u" || -z "$p" || -z "$e" || -z "$m" ]] && echo "⚠ Params kurang" && return
    id "$u" &>/dev/null && echo "⚠ User sudah ada" && return
    useradd -M -N -s /bin/bash "$u" && echo "$u:$p" | chpasswd
    chage -E "$(date -d "+$e days" +"%Y-%m-%d")" "$u"
    echo "$u hard maxlogins $m" >/etc/security/limits.d/"$u.conf"
    sed -i "/^$u:/d" "$EXP_FILE"
    echo "$u:$(date -d "+$e days" +"%Y-%m-%d")" >> "$EXP_FILE"
    echo -e "${GREEN}✅ User $u dibuat${RESET}"
}

create_trial(){
    local u p m
    u=$(tr -dc a-z0-9 </dev/urandom | head -c2)
    while id "$u" &>/dev/null; do u=$(tr -dc a-z0-9 </dev/urandom | head -c2); done
    p=$(tr -dc A-Za-z0-9 </dev/urandom | head -c2)
    m=20
    useradd -M -N -s /bin/bash "$u" && echo "$u:$p" | chpasswd
    chage -E "$(date -d "+1 day" +"%Y-%m-%d")" "$u"
    echo "$u hard maxlogins $m" >/etc/security/limits.d/"$u.conf"
    sed -i "/^$u:/d" "$EXP_FILE"
    echo "$u:$(date -d "+1 day" +"%Y-%m-%d")" >> "$EXP_FILE"
    echo -e "${GREEN}⚡ Trial $u dibuat${RESET}"
}

list_user(){ awk -F: '$3>=1000 && $1!="nobody"{print $1}' /etc/passwd; }

delete_user(){ read -p "Username: " u; id "$u" &>/dev/null || { echo "❌ Tidak ada"; return; }; userdel -r "$u"; rm -f /etc/security/limits.d/"$u.conf"; sed -i "/^$u:/d" "$EXP_FILE"; echo "✅ $u dihapus"; }

renew_user(){ read -p "Username: " u; read -p "Tambah hari: " d; id "$u" &>/dev/null || { echo "❌ Tidak ada"; return; }; curr=$(chage -l "$u" | awk -F": " '/Account expires/ {print $2}'); [[ "$curr"=="never" ]] && curr=$(date +%Y-%m-%d); new=$(date -d "$curr +$d days" +"%Y-%m-%d"); chage -E "$new" "$u"; sed -i "/^$u:/d" "$EXP_FILE"; echo "$u:$new" >> "$EXP_FILE"; echo "✅ $u diperpanjang sampai $new"; }

delete_expired_manual(){
    today=$(date +%s)
    while IFS=: read -r u exp; do
        [[ -z "$u" || -z "$exp" ]] && continue
        exp_epoch=$(date -d "${exp//,/}" +%s 2>/dev/null)
        [[ -z "$exp_epoch" ]] && continue
        [[ $today -ge $exp_epoch ]] && echo "🗑 $u expired $exp"
    done < "$EXP_FILE"
}

backup_data(){
    mkdir -p "$BACKUP_DIR"
    awk -F: '$3>=1000 && $1!="nobody"{print $1}' /etc/passwd > "$BACKUP_DIR/users.list"
    > "$BACKUP_DIR/shadow.backup"
    for u in $(cat "$BACKUP_DIR/users.list"); do
        grep "^$u:" /etc/shadow >> "$BACKUP_DIR/shadow.backup"
        chage -l "$u" | awk -F": " '/Account expires/ {print $2}' > "$BACKUP_DIR/$u.expire"
    done
    [[ -f $HOST_FILE ]] && cp "$HOST_FILE" "$BACKUP_DIR/"
    tar -czf /root/udp/backup_ssh.tar.gz -C /root/udp backup
    LINK=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://0x0.st)
    echo "Backup link: $LINK"
}

restore_data(){
    read -p "Masukkan link: " link
    wget -qO /root/udp/backup_ssh.tar.gz "$link"
    tar -xzf /root/udp/backup_ssh.tar.gz -C /root/udp/
    cd /root/udp/backup || return
    for u in $(cat users.list 2>/dev/null); do
        [[ ! $(id -u "$u" 2>/dev/null) ]] && useradd -M -N -s /bin/bash "$u"
        line=$(grep "^$u:" shadow.backup 2>/dev/null)
        [[ -n "$line" ]] && (sed -i "/^$u:/d" /etc/shadow && echo "$line" >> /etc/shadow)
        [[ -f "$u.expire" ]] && chage -E "$(cat $u.expire)" "$u"
    done
    [[ -f host.conf ]] && cp host.conf "$HOST_FILE"
    echo "✅ Restore selesai"
}

case "$1" in
    create_user) shift; create_user "$@" ;;
    create_trial) create_trial ;;
    list_user) list_user ;;
    delete_user) delete_user ;;
    renew_user) renew_user ;;
    delete_expired_manual) delete_expired_manual ;;
    view_host) view_host ;;
    set_host) shift; set_host "$1" ;;
    reset_host) reset_host ;;
    backup_data) backup_data ;;
    restore_data) restore_data ;;
    *) echo "Unknown command" ;;
esac